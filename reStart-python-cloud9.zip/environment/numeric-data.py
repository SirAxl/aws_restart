print("Python tiene tres tipos numericos: int, float, y complex")



miValor=10

print(type(miValor))
print(str(miValor) + " es el tipo de dato " + str(type(miValor)))




miValor2=3.1415

print(miValor2)
print (type(miValor2))
print(str(miValor2) + " es el tipo de dato" + str(type(miValor2)))


miValor3=5k

print(miValor3)
print(type(miValor3))
print(str(miValor3) + " es el tipo de dato" + str(type(miValor3)))